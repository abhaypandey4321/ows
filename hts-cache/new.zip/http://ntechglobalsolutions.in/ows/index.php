<!DOCTYPE html>
<html>
<head>
	<title>Aspects Fieldwork & Research | Marketing Research Company</title>

	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.0/animate.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    
    <!-- FAVICON -->
    <link rel="shortcut icon" type="image/jpg" href="images/logo.png"/>

    <!-- Fontawsome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <!--Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.min.js"></script>

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
	<link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro&display=swap" rel="stylesheet">

    <!-- NUMBER COUNTER -->
    <script src="js/numscroller-1.0.js"></script>

    <script>
        new WOW().init();
    </script>

    <!-- CUSTOM CSS -->
    <style type="text/css">
    	*{
    		font-family: 'Source Sans Pro', sans-serif;
		}
		#bg_slider{
        	background-image: url(images/ARF_Slider.jpeg);
        	background-size: cover;
        	background-repeat: no-repeat;
        	padding-bottom: 210px;
        	width: 100%;
        }
        #defaultmenu ul li a:hover{
        	background: none;
            color: #7AA4BA;
        }
		#social_menus ul li{
			list-style-type: none;
			display: inline;
		}
		#social_menus ul li a{
			font-size: 20px;
			color: #fff;
		}
		ul li ul.dropdown{
            min-width: 100%; /* Set width of the dropdown */
            background: #f2f2f2;
            display: none;
            position: absolute;
            z-index: 999;
            left: 0;
        }
        ul li:hover ul.dropdown-menu{
            display: block;	/* Display the dropdown */
        }
        ul li ul.dropdown-menu li{
            display: block;
        }
        .img-responsive:hover{
            opacity: 0.6;
        }
                #fb:hover{
            color: #4267B2;
        }
        #insta:hover{
            color: #8a3ab9;
        }
        #twitter:hover{
            color:#1DA1F2;
        }
        #link:hover{
            color: #0077b5;
        }
        #youtube:hover{
            color: #FF0000;
        }
        textarea{
            resize: none;
        }
        .block{
            background-image: linear-gradient(to left,transparent,transparent 50%,#3A56A1 50%,#3A56A1);
            background-position: 100% 0;
            background-size: 200% 100%;
            transition: all .25s ease-in;
        }
        .block:hover{
            background-position: 0 0;
            color:#fff;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-default navbar-fixed-top" role="navigation">
    <div class="container">
	    <div class="navbar-header">
	        <a href="#">
	            <img src="images/logo_1.png" style="width:30%;" class="hidden-xs hidden-sm">
	            <img src="images/logo_1.png" style="height: 90px;width:65%;" class="hidden-lg hidden-md">
	        </a>
	       <button type="button" data-toggle="collapse" data-target="#defaultmenu" class="navbar-toggle" style="margin-top: 8%;">
	           <span class="icon-bar" style="background-color: #000;"></span>
	           <span class="icon-bar" style="background-color: #000;"></span>
	           <span class="icon-bar" style="background-color: #000;"></span>
	       </button>
	   </div>
	   <div id="defaultmenu" class="navbar-collapse collapse">
	       <ul class="nav navbar-nav navbar-right" style="margin-top: -8%;">
	           <li><a href="index.php">Home</a></li>
	           <li><a href="about.php">About Us</a></li>
	           <li class="dropdown">
	               <a class="dropdown-toggle" data-toggle="dropdown" href="#">Services<span class="caret"></span></a>
	               <ul class="dropdown-menu" style="background-color: #3A56A1;">
	                   <center>
	                   <li><a href="service_1.php" style="border-bottom: 1px solid #dcdcdc;color: #fff;">Qualitative</a></li>
	                   <li><a href="service_2.php" style="border-bottom: 1px solid #dcdcdc;color: #fff;">Quantitative</a></li>
	                   <li><a href="service_3.php" style="border-bottom: 1px solid #dcdcdc;color: #fff;">Other Services</a></li>
	                   </center>
	               </ul>
	           </li>
	           <li><a href="industry.php">Industry</a></li>
	           <li><a href="coverage.php">Coverage</a></li>
	           <li><a href="contact.php">Contact Us</a></li>
	           <li><a href="join_our_panel.php"><button type="button" class="btn btn-xs btn-success">Join our panel</button></a></li>
	       </ul>
	   </div>
    </div>
</nav>
<br><br><br><br><br><br> 
<div id="bg_slider">
	<div class="container">
		<div class="row wow fadeInUp">
		    <div class="col-sm-6 col-md-6 col-lg-6">
			    <div style="margin-top: 22.2%;">
			        <!--<center>-->
			            <h1 style="font-family: 'Source Sans Pro', sans-serif;font-size: 60px;font-weight:bolder;color:#fff;"><b>Aspects Fieldwork & Research</b></h1>
				        <center><b style="font-size: 20px;">REDIRECTING CURIOSITY IN THE RIGHT DIRECTION</b></center>
			        <!--</center>-->
			    </div>
			</div>
			<div class="col-sm-6 col-md-6 col-lg-6">
			    <!--<center>-->
				<!-- CAROUSEL -->
				<div id="myCarousel" class="carousel slide" data-ride="carousel" style="margin-top: 18%;">

				    <!-- Wrapper for slides -->
				    <div class="carousel-inner">
				    	<div class="item active">
				        	<h1 class="text-primary" style="font-size: 60px;font-family: 'Source Sans Pro', sans-serif;color:#000;">
				        		Know your Audience
				        	</h1>
				        	<p style="font-size: 19px;color: #000;font-family: 'Source Sans Pro', sans-serif;color: #222;">
				        		Identify and understand on what stage your audience is and make a compelling strategy to convert them into your potential 
				        		customers with the help of our targeted research
				        	</p>
				      	</div>

				      	<div class="item">
				        	<h1 class="text-primary" style="font-size: 60px;font-family: 'Source Sans Pro', sans-serif;color:#000;">
				        		Expand your Business
				        	</h1>
				        	<p style="font-size: 19px;color: #000;font-family: 'Source Sans Pro', sans-serif;color: #222;">
				        		Be it any industry, an effortless expansion of business with the help of in-depth analysis makes the journey smoother
				        	</p>
				      	</div>

				      	<div class="item">
				        	<h1 class="text-primary" style="font-size: 60px;font-family: 'Source Sans Pro', sans-serif;color:#000;">
				        		Understand Audience
				        	</h1>
				        	<p style="font-size: 19px;color: #000;font-family: 'Source Sans Pro', sans-serif;color: #222;">
				        		Knowing your audience isn’t enough. Knowing their interests, needs, barriers, motivation elevates your brand to connect 
				        		and understand your targeted groups
				        	</p>
				      	</div>
				    </div>
				</div>
				<!--</center>-->
			</div>
			<!--<div class="col-sm-6 col-md-6 col-lg-6 hidden-xs hidden-sm">-->
			<!--    <div style="margin-top: 14.2%;">-->
			<!--        <center>-->
			<!--            <h1 style="font-family: 'Source Sans Pro', sans-serif;color: #fff;font-size: 60px;">Aspects Fieldwork & Research</h1>-->
			<!--	        <center><b style="font-size: 20px;">REDIRECTING CURIOSITY IN THE RIGHT DIRECTION</b></center>-->
			<!--        </center>-->
			<!--    </div>-->
			<!--</div>-->
		</div>
	</div>
</div>
<!-- ABOUT US -->
<div class="container">
	<div class="row">
		<div class="col-sm-6 col-md-6 col-lg-6">
		    <!--<br><br>-->
		    <img src="images/about.png" style="width: 100%;">
		</div>
		<div class="col-sm-6 col-md-6 col-lg-6">
		    <br>
			<center class="wow fadeInUp">
				<h2 style="font-family: 'Source Sans Pro', sans-serif;background-color: #3A56A1;color: #fff;padding: 10px 20px;border-radius: 5px;border: 2px solid #000;">About Aspects Fieldwork & Research</h2> <!-- #04abeb -->
				<center><b style="font-size: 20px;">REDIRECTING CURIOSITY IN THE RIGHT DIRECTION</b></center>
				<br>
				<p style="text-align: justify;font-size: 16px;line-height: 24px;color: #000;">
				    <span class="block">
					Aspects Fieldwork & Research is a leading market research, analytics, and consulting firm that helps curate and extract the information you need to make accurate business decisions and track your competitive environment. Headquartered in Mumbai, India, Aspects Fieldwork & Research has a strong international presence spread across several other countries.</span>
					<br><br>
					<span class="block">
					Our products and services are designed to help organizations everywhere redirect their curiosity in the right direction. Everyday people around the globe use Aspects Fieldwork & Research to find answers to millions of questions. These answers compile to become an evaluation that drives companies to grow, succeed, and formulate to solve today’s most compelling challenges.</span>
					<br><br>
					<span class="block">
					We thrive to develop new ways to innovate new ways for people to amplify their share of voices
					and opinions. Our research funnel is strategically divided as per the enterprise-grade format, focusing on small to large size organizations.</span>
					<br><br>
					<span class="block">
					Empowering millions of active users to bring better products and services to the market by doing intricate and authentic details, delight their website and app users, promote customer loyalty, encourage their employees, and much more.</span>
				</p>
			</center>
		</div>
	</div>
</div>
<br>
<!-- Our Servies -->
<div class="container-fluid" style="background-color: #3A56A1;padding: 40px 20px;">
	<div class="row">
		<center>
			<h2 style="font-weight:bolder;color: #fff;">Our Services</h2>
		</center>
		<div class="col-sm-6 col-md-4 col-lg-4">
			<div style="background-color: #f5ebeb;padding: 10px 20px;"> <!-- height: 227px; -->
				<div>
					<h4><b>Qualitative</b></h4>
					<p>
						Also known as primary research, qualitative analysis demands interaction and real-time data. This is the process of collating data 
						that hasn’t been out there yet. Interviews, market research surveys, questionnaires, and more fall under qualitative or primary research.
					</p>
					<br class="hidden-lg hidden-sm hidden-xs">
					<center>
					    <a href="service_1.php">
					        <button type="button" class="btn btn-md btn-success">View More</button>
					    </a>
					</center>
				</div>
			</div>
		</div>
		<div class="col-sm-6 col-md-4 col-lg-4">
			<div style="background-color: #dcebdd;padding: 10px 20px;"> <!-- height: 224px; -->
				<div>
					<h4><b>Quantitative</b></h4>
					<p>
						When numbers and figures come together to form a proper analysis, it is called quantitative research. It is majorly used to find patterns 
						and averages, make predictions, and generalize results to a wider population.Quantitative research is widely used in understanding customer psychology.
					</p>
					<center>
					    <a href="service_2.php">
					        <button type="button" class="btn btn-md btn-success">View More</button>
					    </a>
					</center>
				</div>
			</div>
		</div>
		<div class="col-sm-12 col-md-4 col-lg-4">
			<div style="background-color: #f5efd8;padding: 10px 20px;">
				<div>
					<h4><b>Other Services</b></h4>
					<p>
						Aspects Fieldwork & Research is known for its dedication and competency to do comprehensive research for any industry across the country. 
						This not only gives you a wide coverage, but also assures you of realistic data, statistics, and information to kickstart your 
						business or launch a new product.
					</p>
					<center>
					    <a href="service_3.php">
					        <button type="button" class="btn btn-md btn-success">View More</button>
					    </a>
					</center>
				</div>
			</div>
		</div>
	</div>
</div>
<br>
<!-- Industry We work -->
<div class="container">
	<center class="wow fadeInUp">
		<h2 style="font-weight:bolder;" class="text-primary">Industry We Work With</h2>
	</center>
	<div class="row wow fadeInUp">
		<div class="col-xs-6 col-sm-6 col-md-6 col-lg-3">
			<img src="images/industry/agri.jpg" class="img-responsive" style="width: 100%;">
			<center><h4 style="background-color: #f2f2f2;border: 1px solid #dcdcdc;padding: 10px 20px;margin-top: -1%;">Agriculture</h4></center>
		</div>
		<div class="col-xs-6 col-sm-6 col-md-6 col-lg-3">
			<img src="images/industry/automotive.jpg" class="img-responsive" style="width: 100%;">
			<center><h4 style="background-color: #f2f2f2;border: 1px solid #dcdcdc;padding: 10px 20px;margin-top: -1%;">Automotive</h4></center>
		</div>
		<div class="col-xs-6 col-sm-6 col-md-6 col-lg-3">
			<img src="images/industry/aviation.jpg" class="img-responsive" style="width: 100%;">
			<center><h4 style="background-color: #f2f2f2;border: 1px solid #dcdcdc;padding: 10px 20px;margin-top: -1%;">Aviation</h4></center>
		</div>
		<div class="col-xs-6 col-sm-6 col-md-6 col-lg-3">
			<img src="images/industry/ecom.jpg" class="img-responsive" style="width: 100%;">
			<center><h4 style="background-color: #f2f2f2;border: 1px solid #dcdcdc;padding: 10px 20px;margin-top: -1%;">Ecommerce</h4></center>
		</div>
	</div>
	<br>
	<div class="row wow fadeInUp">
		<div class="col-xs-6 col-sm-6 col-md-6 col-lg-3">
			<img src="images/industry/education.jpg" class="img-responsive" style="width: 100%;">
			<center><h4 style="background-color: #f2f2f2;border: 1px solid #dcdcdc;padding: 10px 20px;margin-top: -1%;">Education</h4></center>
		</div>
		<div class="col-xs-6 col-sm-6 col-md-6 col-lg-3">
			<img src="images/industry/electronic.jpg" class="img-responsive" style="width: 100%;">
			<center><h4 style="background-color: #f2f2f2;border: 1px solid #dcdcdc;padding: 10px 20px;margin-top: -1%;">Electronic</h4></center>
		</div>
		<div class="col-xs-6 col-sm-6 col-md-6 col-lg-3">
			<img src="images/industry/film.jpg" class="img-responsive" style="width: 100%;">
			<center><h4 style="background-color: #f2f2f2;border: 1px solid #dcdcdc;padding: 10px 20px;margin-top: -1%;">Film</h4></center>
		</div>
		<div class="col-xs-6 col-sm-6 col-md-6 col-lg-3">
			<img src="images/industry/fmcg.jpg" class="img-responsive" style="width: 100%;">
			<center><h4 style="background-color: #f2f2f2;border: 1px solid #dcdcdc;padding: 10px 20px;margin-top: -1%;">FMCG Market</h4></center>
		</div>
	</div>
	<br>
	<center>
	    <a href="industry.php">
		    <button type="button" class="btn btn-sm btn-success">View More</button>
	    </a>
	</center>
</div>
<br>
<!-- COVERAGE -->
<div class="container">
    <center class="wow fadeInUp">
		<h2 style="font-weight:bolder;" class="text-primary">Coverage</h2>
	</center>
    <img src="images/New_Map.png" style="border: 2px solid #dcdcdc;width: 100%;">
</div>
<br>
<!-- Contact Us -->
<div style="background-color: #3A56A1;padding: 38px 20px;"> <!--  -->
	<center>
		<h1 style="color: #fff;">Contact Us</h1>
	</center>
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-6 col-md-6 col-lg-6">
				<form class="form" action="mail.php" method="POST">
					<input type="text" name="name" class="form-control" placeholder="Enter Name" required>
					<br>
					<input type="email" name="email" class="form-control" placeholder="Enter Email" required>
					<br>
					<input type="text" name="con" class="form-control"  placeholder="Enter Contact with Country Code. For eg +91" required>
					<br>
					<input type="text" name="sub" class="form-control"  placeholder="Enter Subject" required>
					<br>
					<textarea rows="10" cols="20" class="form-control" required></textarea>
					<br>
					<center><button type="submit" class="btn btn-md btn-success">Submit</button></center>
				</form>
			</div>
			<div class="col-sm-6 col-md-6 col-lg-6">
    		    <br><br>
    		    <center>
    		        <img src="images/A.png" style="width: 100%;">
    		    </center>
		    </div>
		</div>
	</div>
</div>
<!-- Footer -->

<!--
<div style="background-color: #000;padding: 18px 20px;">
	<div class="container">
		<div class="row">
			<div class="col-md-4 col-lg-4">
			    <center>
    			    <h3 style="color: #fff;">
    				   <i class="fa fa-map"></i> &nbsp; Akshya Nagar 1st Block 1st Cross, Rammurthy nagar Bangalore-560016
    				</h3>
    			</center>
			</div>
			<div class="col-md-4 col-lg-4">
			    <center>
    			    <h3 style="color: #fff;">
    			        <i class="fa fa-envelope"></i> &nbsp; info@aspectsfieldwork.com
    			        <br>
    			        <i class="fa fa-envelope"></i> &nbsp; panel@aspectsfieldwork.com
    			        <br>
    			        <i class="fa fa-phone"></i> &nbsp; +91 9876543210
    			    </h3>
			    </center>
			</div>
			<div class="col-md-4 col-lg-4">
			    <br>
			    <center>
			        <div id="social_menus">
						<ul>
							<li><a href="#"><i class="fa fa-facebook" id="fb"></i></a></li>&nbsp;&nbsp;&nbsp;&nbsp;
							<li><a href="#"><i class="fa fa-instagram" id="insta"></i></a></li>&nbsp;&nbsp;&nbsp;&nbsp;
							<li><a href="#"><i class="fa fa-twitter" id="twitter"></i></a></li>&nbsp;&nbsp;&nbsp;&nbsp;
							<li><a href="#"><i class="fa fa-linkedin" id="link"></i></a></li>&nbsp;&nbsp;&nbsp;&nbsp;
							<li><a href="#"><i class="fa fa-youtube" id="youtube"></i></a></li>
						</ul>
					</div>
				</center>
			</div>
		</div>
	</div>
</div>


<div id="footer" style="background-color: #000;">
	<div class="container">
		<div class="row">
			<div class="col-sm-6 col-md-4 col-lg-4">
				<!--<center>
					<h2 style="color: #fff;">About Us</h2>
					<p style="text-align: justify;color: #fff;">
						Aspects Fieldwork & Research is a leading market research, analytics, and consulting firm that helps curate and extract the information you need to make accurate business decisions and track your competitive environment. Headquartered in Mumbai, India, One Way Solution has a strong international presence spread across several other countries.
					</p>
				</center>
				
				<center>
					<h2 style="color: #fff;">Address</h2>
					<p style="text-align: justify;color: #fff;">
						Akshya Nagar 1st Block 1st Cross, Rammurthy nagar Bangalore-560016
					</p>
				</center>
			</div>
			<div class="col-sm-6 col-md-4 col-lg-4">
				<center>
				    <h2 style="color: #fff;">Services</h2>
				    <ul>
				        <li style="list-style-type:none;"><a href="service_1.php" style="color:#fff;text-decoration:none;">Qualitative</a></li>
				        <li style="list-style-type:none;"><a href="service_2.php" style="color:#fff;text-decoration:none;">Quantitative</a></li>
				        <li style="list-style-type:none;"><a href="service_3.php" style="color:#fff;text-decoration:none;">Other Services</a></li>
				    </ul>
				</center>
			</div>
			<div class="col-sm-12 col-md-4 col-lg-4">
				<center>
					<h2 style="color: #fff;">Connect With Us</h2>
					<div id="social_menus">
						<ul>
							<li><a href="#"><i class="fa fa-facebook"></i></a></li>&nbsp;&nbsp;&nbsp;&nbsp;
							<li><a href="#"><i class="fa fa-instagram"></i></a></li>&nbsp;&nbsp;&nbsp;&nbsp;
							<li><a href="#"><i class="fa fa-twitter"></i></a></li>&nbsp;&nbsp;&nbsp;&nbsp;
							<li><a href="#"><i class="fa fa-linkedin"></i></a></li>&nbsp;&nbsp;&nbsp;&nbsp;
							<li><a href="#"><i class="fa fa-youtube"></i></a></li>
						</ul>
					</div>
				</center>
			</div>
		</div>
		<hr>
	</div>
</div> -->

<style>
    footer{
  background: #fff; /* #ea018a */ /*58FD1A */
  width: 100%;
  bottom: 0;
  left: 0;
  border-top: 1px solid #dcdcdc;
}
footer::before{
  content: '';
  position: absolute;
  left: 0;
  /*top: 100px;*/
  /*height: 1px;*/
  width: 100%;
  background: #000;
}
footer .content{
  max-width: 1250px;
  margin: auto;
  /*padding: 30px 40px 40px 40px;*/
}
footer .content .top{
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 50px;
}
.content .top .logo-details{
  color: #fff;
  font-size: 30px;
}
.content .top .media-icons{
  display: flex;
}
.content .top .media-icons a{
  height: 40px;
  width: 40px;
  margin: 0 8px;
  border-radius: 50%;
  text-align: center;
  line-height: 40px;
  color: #fff;
  font-size: 17px;
  text-decoration: none;
  transition: all 0.4s ease;
}
.top .media-icons a:nth-child(1){
  background: #4267B2;
}
.top .media-icons a:nth-child(1):hover{
  color: #4267B2;
  background: #fff;
}
.top .media-icons a:nth-child(2){
  background: #1DA1F2;
}
.top .media-icons a:nth-child(2):hover{
  color: #1DA1F2;
  background: #fff;
}
.top .media-icons a:nth-child(3){
  background: #E1306C;
}
.top .media-icons a:nth-child(3):hover{
  color: #E1306C;
  background: #fff;
}
.top .media-icons a:nth-child(4){
  background: #0077B5;
}
.top .media-icons a:nth-child(4):hover{
  color: #0077B5;
  background: #fff;
}
.top .media-icons a:nth-child(5){
  background: #FF0000;
}
.top .media-icons a:nth-child(5):hover{
  color: #FF0000;
  background: #fff;
}
footer .content .link-boxes{
  width: 100%;
  display: flex;
  justify-content: space-between;
}
footer .content .link-boxes .box{
  width: calc(100% / 5 - 10px);
}
.content .link-boxes .box .link_name{
  color: #000;
  font-size: 18px;
  font-weight: bold;
  margin-bottom: 10px;
  position: relative;
}
.link-boxes .box .link_name::before{
  content: '';
  position: absolute;
  left: 0;
  bottom: -2px;
  height: 2px;
  width: 35px;
  background: orange;
}
.content .link-boxes .box li{
  margin: 6px 0;
  list-style: none;
}
.content .link-boxes .box li a{
  color: #F20C78;
  font-size: 14px;
  font-weight: bold;
  text-decoration: none;
  opacity: 0.8;
  transition: all 0.4s ease
}
.content .link-boxes .box li a:hover{
  opacity: 1;
  text-decoration: underline;
}
.content .link-boxes .input-box{
  margin-right: 55px;
}
.link-boxes .input-box input{
  height: 40px;
  width: calc(100% + 55px);
  outline: none;
  border: 2px solid orange; /*#AFAFB6*/
  background: #140B5C;
  border-radius: 4px;
  padding: 0 15px;
  font-size: 15px;
  color: #fff;
  margin-top: 5px;
}
.link-boxes .input-box input::placeholder{
  color: #AFAFB6;
  font-size: 16px;
}
.link-boxes .input-box input[type="button"]{
  background: #fff;
  color: #140B5C;
  border: none;
  font-size: 18px;
  font-weight: 500;
  margin: 4px 0;
  opacity: 0.8;
  cursor: pointer;
  transition: all 0.4s ease;
}
.input-box input[type="button"]:hover{
  opacity: 1;
}
footer .bottom-details{
  width: 100%;
background: #000; /*2c303a*/
}
footer .bottom-details .bottom_text{
  max-width: 1250px;
  margin: auto;
  padding: 20px 40px;
  display: flex;
  justify-content: space-between;
}
.bottom-details .bottom_text span,
.bottom-details .bottom_text a{
  font-size: 14px;
  font-weight: 300;
  color: #fff;
  opacity: 0.8;
  text-decoration: none;
}
.bottom-details .bottom_text a:hover{
  opacity: 1;
  text-decoration: underline;
}
.bottom-details .bottom_text a{
  margin-right: 10px;
}
@media (max-width: 900px) {
  footer .content .link-boxes{
    flex-wrap: wrap;
  }
  footer .content .link-boxes .input-box{
    width: 40%;
    margin-top: 10px;
  }
}
@media (max-width: 700px){
  footer{
    position: relative;
  }
  .content .top .logo-details{
    font-size: 26px;
  }
  .content .top .media-icons a{
    height: 35px;
    width: 35px;
    font-size: 14px;
    line-height: 35px;
  }
  footer .content .link-boxes .box{
    width: calc(100% / 3 - 10px);
  }
  footer .content .link-boxes .input-box{
    width: 60%;
  }
  .bottom-details .bottom_text span,
  .bottom-details .bottom_text a{
    font-size: 12px;
  }
}
@media (max-width: 520px){
  footer::before{
    top: 145px;
  }
  footer .content .top{
    flex-direction: column;
  }
  .content .top .media-icons{
    margin-top: 16px;
  }
  footer .content .link-boxes .box{
    width: calc(100% / 2 - 10px);
  }
  footer .content .link-boxes .input-box{
    width: 100%;
  }
}
.text {
  color: white;
  font-size: 20px;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  white-space: nowrap;
}

@charset "UTF-8";

.svg-inline--fa {
  vertical-align: -0.200em;
}

.rounded-social-buttons {
  text-align: center;
  padding: 08px 0px;
  margin-left: -8.7%;
}

.rounded-social-buttons .social-button {
  display: inline-block;
  position: relative;
  cursor: pointer;
  width: 3.125rem;
  height: 3.125rem;
  border: 0.125rem solid transparent;
  padding: 0;
  text-decoration: none;
  text-align: center;
  color: #fefefe;
  font-size: 1.5625rem;
  font-weight: normal;
  line-height: 2em;
  border-radius: 1.6875rem;
  transition: all 0.5s ease;
  margin-right: 0.25rem;
  margin-bottom: 0.25rem;
}

.rounded-social-buttons .social-button:hover, .rounded-social-buttons .social-button:focus {
  -webkit-transform: rotate(360deg);
      -ms-transform: rotate(360deg);
          transform: rotate(360deg);
}

.rounded-social-buttons .fa-twitter, .fa-facebook-f, .fa-linkedin, .fa-youtube, .fa-instagram {
  font-size: 25px;
}

.rounded-social-buttons .social-button.facebook {
  background: #3b5998;
}

.rounded-social-buttons .social-button.facebook:hover, .rounded-social-buttons .social-button.facebook:focus {
  color: #3b5998;
  background: #fefefe;
  border-color: #3b5998;
}

.rounded-social-buttons .social-button.twitter {
  background: #55acee;
}

.rounded-social-buttons .social-button.twitter:hover, .rounded-social-buttons .social-button.twitter:focus {
  color: #55acee;
  background: #fefefe;
  border-color: #55acee;
}

.rounded-social-buttons .social-button.linkedin {
  background: #007bb5;
}

.rounded-social-buttons .social-button.linkedin:hover, .rounded-social-buttons .social-button.linkedin:focus {
  color: #007bb5;
  background: #fefefe;
  border-color: #007bb5;
}

.rounded-social-buttons .social-button.youtube {
  background: #bb0000;
}

.rounded-social-buttons .social-button.youtube:hover, .rounded-social-buttons .social-button.youtube:focus {
  color: #bb0000;
  background: #fefefe;
  border-color: #bb0000;
}

.rounded-social-buttons .social-button.instagram {
  background: #125688;
}

.rounded-social-buttons .social-button.instagram:hover, .rounded-social-buttons .social-button.instagram:focus {
  color: #125688;
  background: #fefefe;
  border-color: #125688;
}
</style>

<footer>
	<div class="content">
		<div class="top">
			<div class="logo-details">
				<!--<span class="logo_name">Aspects Fieldwork & Research</span>-->
				
			</div>
			
		</div>
		<div class="link-boxes">
		    <ul class="box">
				<li><a href="#"><img src="images/logo_1.png" style="width:150%;"></a></li>
			</ul>
		    <ul class="box">
				<li class="link_name">Services</li>
				<li><a href="service_1.php">Qualitative</a></li>
				<li><a href="service_2.php">Quantitative</a></li>
				<li><a href="service_3.php">Other Services</a></li>
			</ul>
			<ul class="box">
				<li class="link_name">Address</li>
                <p style="color:#F20C78;font-weight: bold;">Akshya Nagar 1st Block 1st Cross, Rammurthy nagar Bangalore-560016</p>
			</ul>
			<!--
            <ul class="box">
				<li class="link_name">Important Links</li>
				<li><a href="#">Home</a></li>
				<li><a href="#">About Us</a></li>
				<li><a href="#">Industry</a></li>
				<li><a href="#">Coverage</a></li>
			</ul>
			-->
			<ul class="box">
				<li class="link_name">Contact</li>
				<li><a href="#" tel="919874563120">+91 9874563120</a></li>
				<li><a href="#">+91 9874563210</a></li>
				<li><a href="#">contact@arf.com</a></li>
				<div class="rounded-social-buttons">
                    <a class="social-button facebook" href="https://www.facebook.com/" target="_blank"><i class="fab fa-facebook-f"></i></a>
                    <a class="social-button twitter" href="https://www.twitter.com/" target="_blank"><i class="fab fa-twitter"></i></a>
                    <a class="social-button linkedin" href="https://www.linkedin.com/" target="_blank"><i class="fab fa-linkedin"></i></a>
                    <a class="social-button youtube" href="https://www.youtube.com/" target="_blank"><i class="fab fa-youtube"></i></a>
                    <a class="social-button instagram" href="https://www.instagram.com/" target="_blank"><i class="fab fa-instagram"></i></a>
                </div>
				<!--
				<div class="">
				    <ul style="display:inline;">
				        <li><a href="#"><img src="images/fb_logo.png" class="img-responsive" style="width: 10%;"></a></li>
				        <li><a href="#"><img src="images/linkedin.png" class="img-responsive" style="width: 10%;"></a></li>
				        <li><a href="#"><img src="images/instagram.png" class="img-responsive" style="width: 10%;"></a></li>
				        <li><a href="#"><img src="images/youtube.png" class="img-responsive" style="width: 10%;"></a></li>
				    </ul>
			    </div>
			    -->
			</ul>
		</div>
	</div>
	<div class="bottom-details">
        <div class="bottom_text">
            <span class="copyright_text">Copyright © 2021 <a href="#">Aspects Fieldwork & Research</a>| Design & Developed By <a href="#">Ntech Global Solutions</a></span>
            <span class="policy_terms">
            <!--<a href="#">Privacy policy</a>-->
        </span>
      </div>
    </div>
</footer>
<script defer src="https://use.fontawesome.com/releases/v5.0.13/js/all.js" integrity="sha384-xymdQtn1n3lH2wcu0qhcdaOpQwyoarkgLVxC/wZ5q7h9gHtxICrpcaSUfygqZGOe" crossorigin="anonymous"></script>
</body>
</html>